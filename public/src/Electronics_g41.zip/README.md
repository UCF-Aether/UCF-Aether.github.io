<p align="center">
  <img src="https://user-images.githubusercontent.com/5152848/165011265-b768cf11-c5b3-4744-96b1-b509ce99ebe8.png" />
</p>

# Aether Electronics
The schematic is viewable as a PDF in the latest release. To view in KiCad, make sure you have KiCad 6 installed, and simply clone the repo and open `aether.kicad_pro`.
