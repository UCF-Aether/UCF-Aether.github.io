insert into cayenne.map (key, val, decode_to)
values (7, 'PM1_0', 'FLOAT'),
       (8, 'PM2_5', 'FLOAT'),
       (9, 'PM4_0', 'FLOAT'),
       (10, 'PM10', 'FLOAT');
