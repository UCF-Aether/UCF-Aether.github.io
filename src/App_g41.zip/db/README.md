# Supabase PostgreSQL Databse Configuration and Schema
## Getting Started
### Install the Supabase CLI
See install instructions [here](https://github.com/supabase/cli#install-the-cli)
