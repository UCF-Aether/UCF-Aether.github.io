<p align="center">
  <img src="https://user-images.githubusercontent.com/5152848/146123906-e0c5a518-798d-49a1-ba78-0f2eeff61f5f.png">
</p>

# Aether App
The repository for the Aether App at [aethersensor.network](https://aethersensor.network/)
