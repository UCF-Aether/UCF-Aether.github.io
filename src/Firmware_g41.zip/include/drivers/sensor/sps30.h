#ifdef __SPS30_UTIL_H__
#define __SPS30_UTIL_H__

#include <kernel.h>


int sps30_init(const struct device *dev);
#endif /* __SPS30_UTIL_H__ */
