#ifndef __PM_H__
#define __PM_H__

void enable_sleep();
void disable_sleep();

#endif /* __PM_H__ */
